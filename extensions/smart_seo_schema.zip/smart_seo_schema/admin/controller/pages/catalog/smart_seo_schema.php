<?php

if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}

class ControllerPagesCatalogSmartSeoSchema extends AController
{
    public $error = array();
    public $data = array();

    public function main()
    {
        $this->loadLanguage('smart_seo_schema/smart_seo_schema');
        $this->loadLanguage('catalog/product');
        $this->loadModel('catalog/product');
        
        $product_id = $this->request->get['product_id'];
        
        if ($this->request->is_POST() && $this->validateForm()) {
            $this->saveSchemaSettings($product_id);
            $this->session->data['success'] = $this->language->get('text_success');
            redirect($this->html->getSecureURL('catalog/smart_seo_schema', '&product_id=' . $product_id));
        }

        $this->document->setTitle($this->language->get('smart_seo_schema_name'));
        
        $product_info = $this->model_catalog_product->getProduct($product_id);
        $this->data['product_description'] = $this->model_catalog_product->getProductDescriptions($product_id);
        $this->data['heading_title'] = $this->language->get('text_edit') . '&nbsp;' . $this->language->get('text_product');

        $this->view->assign('error', $this->error);
        $this->view->assign('success', $this->session->data['success']);
        if (isset($this->session->data['success'])) {
            unset($this->session->data['success']);
        }

        $this->setupBreadcrumb($product_id);

        $this->data['active'] = 'smart_seo_schema';
        $tabs_obj = $this->dispatch('pages/catalog/product_tabs', array($this->data));
        $this->data['product_tabs'] = $tabs_obj->dispatchGetOutput();
        unset($tabs_obj);

        $this->data['schema_settings'] = $this->getSchemaSettings($product_id);
        $this->data['product_variants'] = $this->getProductVariants($product_id);
        $this->data['product_reviews'] = $this->getProductReviews($product_id);
        $this->data['ai_status'] = $this->checkAIConnection();
        
        $this->setupForm($product_id);

        $this->addChild('pages/catalog/product_summary', 'summary_form', 'pages/catalog/product_summary.tpl');

        $this->view->batchAssign($this->data);
        $this->processTemplate('pages/smart_seo_schema/smart_seo_schema_form.tpl');
    }

    public function testAIConnection()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $this->loadLanguage('smart_seo_schema/smart_seo_schema');
            
            $api_key = $this->config->get('smart_seo_schema_groq_api_key');
            $model = $this->config->get('smart_seo_schema_groq_model') ?: 'llama-3.1-8b-instant';
            
            $json = array();
            
            $this->logDebug("=== INICIO TEST CONEXIÓN IA ===");
            $this->logDebug("API Key presente: " . (!empty($api_key) ? 'Sí (' . strlen($api_key) . ' chars)' : 'No'));
            $this->logDebug("Modelo configurado: " . $model);
            
            if (!$api_key) {
                $json = array(
                    'error' => true,
                    'message' => 'No API key configured. Please enter your Groq API key in extension settings.',
                    'debug' => 'No API key found in configuration'
                );
                $this->logDebug("Error: No API key configurado");
            } else {
                $this->logDebug("Llamando a Groq API...");
                $response = $this->callGroqAPI($api_key, $model, 'Test connection - please respond with "Connection successful"', 50);
                
                if ($response) {
                    $json = array(
                        'error' => false,
                        'message' => "Connection successful! Model '{$model}' is working properly. Response: " . substr($response, 0, 100) . "...",
                        'response_length' => strlen($response)
                    );
                    $this->logDebug("Éxito: " . $json['message']);
                } else {
                    $json = array(
                        'error' => true,
                        'message' => "Connection failed. No response from API. Check your API key and model '{$model}'.",
                        'debug' => 'Empty response from API'
                    );
                    $this->logDebug("Error: Sin respuesta de la API");
                }
            }
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => "Connection failed: " . $e->getMessage(),
                'debug' => array(
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                )
            );
            $this->logDebug("Excepción capturada: " . $e->getMessage());
        } catch (Error $e) {
            $json = array(
                'error' => true,
                'message' => "Fatal error: " . $e->getMessage(),
                'debug' => array(
                    'error' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                )
            );
            $this->logDebug("Error fatal: " . $e->getMessage());
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function generateMultipleAIContent()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $product_id = $this->request->get['product_id'];
            $content_types = $this->request->post['content_types'];
            
            $this->logDebug("=== GENERANDO CONTENIDO MÚLTIPLE IA CON DIVISIÓN DE TOKENS ===");
            $this->logDebug("Tipos solicitados: " . implode(', ', $content_types));
            $this->logDebug("Producto: " . $product_id);
            
            if (!$product_id || !is_array($content_types) || empty($content_types)) {
                throw new Exception('Missing required parameters or invalid content_types array');
            }
            
            $this->loadModel('catalog/product');
            $product_info = $this->model_catalog_product->getProduct($product_id);
            
            if (!$product_info) {
                throw new Exception('Product not found: ' . $product_id);
            }
            
            $this->logDebug("Producto encontrado: " . $product_info['name']);
            
            $generated_content = $this->generateMultipleAIContentWithTokenDivision($product_info, $content_types);
            
            if (empty($generated_content)) {
                throw new Exception('AI generated empty content for all requested types');
            }
            
            $json = array(
                'error' => false,
                'content' => $generated_content,
                'content_types' => $content_types,
                'product_name' => $product_info['name'],
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            $this->logDebug("Contenido múltiple generado exitosamente - Tipos: " . implode(', ', array_keys($generated_content)));
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage(),
                'debug' => array(
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'trace' => $e->getTraceAsString()
                ),
                'timestamp' => date('Y-m-d H:i:s')
            );
            $this->logDebug("Error generando contenido múltiple: " . $e->getMessage());
        } catch (Error $e) {
            $json = array(
                'error' => true,
                'message' => "Fatal error: " . $e->getMessage(),
                'debug' => array(
                    'error' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                ),
                'timestamp' => date('Y-m-d H:i:s')
            );
            $this->logDebug("Error fatal: " . $e->getMessage());
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit();
    }

    public function getReviewsAjax()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $product_id = $this->request->get['product_id'];
            
            if (!$product_id) {
                throw new Exception('Missing product_id parameter');
            }
            
            $reviews = $this->getProductReviews($product_id);
            
            $json = array(
                'error' => false,
                'reviews' => $reviews,
                'count' => count($reviews)
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage()
            );
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function optimizeReview()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $review_id = $this->request->post['review_id'];
            $review_text = $this->request->post['review_text'];
            $product_id = $this->request->get['product_id'];
            
            if (!$review_id || !$review_text || !$product_id) {
                throw new Exception('Missing required parameters');
            }
            
            $this->loadModel('catalog/product');
            $product_info = $this->model_catalog_product->getProduct($product_id);
            
            if (!$product_info) {
                throw new Exception('Product not found');
            }
            
            $optimized_text = $this->optimizeReviewWithAI($review_text, $product_info);
            
            $json = array(
                'error' => false,
                'optimized_text' => $optimized_text,
                'original_length' => strlen($review_text),
                'optimized_length' => strlen($optimized_text)
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage()
            );
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function generateExampleReview()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $product_id = $this->request->get['product_id'];
            
            if (!$product_id) {
                throw new Exception('Missing product_id parameter');
            }
            
            $this->loadModel('catalog/product');
            $product_info = $this->model_catalog_product->getProduct($product_id);
            
            if (!$product_info) {
                throw new Exception('Product not found');
            }
            
            $example_review = $this->generateExampleReviewWithAI($product_info);
            
            $json = array(
                'error' => false,
                'review' => $example_review
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage()
            );
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function saveReview()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $review_id = $this->request->post['review_id'];
            $product_id = $this->request->post['product_id'];
            $author = $this->request->post['author'];
            $text = $this->request->post['text'];
            $rating = (int)$this->request->post['rating'];
            $verified_purchase = isset($this->request->post['verified_purchase']) ? 1 : 0;
            $status = isset($this->request->post['status']) ? 1 : 0;
            
            if (!$product_id || !$author || !$text || !$rating) {
                throw new Exception('Missing required fields');
            }
            
            if ($rating < 1 || $rating > 5) {
                throw new Exception('Rating must be between 1 and 5');
            }
            
            if ($review_id) {
                $this->updateReview($review_id, $author, $text, $rating, $verified_purchase, $status);
                $message = 'Review updated successfully';
            } else {
                $this->createReview($product_id, $author, $text, $rating, $verified_purchase, $status);
                $message = 'Review created successfully';
            }
            
            $json = array(
                'error' => false,
                'message' => $message
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage()
            );
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function deleteReview()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $review_id = $this->request->post['review_id'];
            
            if (!$review_id) {
                throw new Exception('Missing review_id parameter');
            }
            
            $this->db->query("DELETE FROM " . DB_PREFIX . "reviews WHERE review_id = " . (int)$review_id);
            
            $json = array(
                'error' => false,
                'message' => 'Review deleted successfully'
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage()
            );
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function getVariants()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $product_id = $this->request->get['product_id'];
            
            if (!$product_id) {
                throw new Exception('Missing product_id parameter');
            }
            
            $variants = $this->getProductVariants($product_id);
            
            $json = array(
                'error' => false,
                'variants' => $variants,
                'count' => count($variants)
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => $e->getMessage()
            );
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function previewSchema()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $product_id = $this->request->get['product_id'];
            
            if (!$product_id) {
                throw new Exception('Missing product_id parameter');
            }
            
            $this->loadModel('catalog/product');
            $product_info = $this->model_catalog_product->getProduct($product_id);
            
            if (!$product_info) {
                throw new Exception('Product not found: ' . $product_id);
            }
            
            if (!class_exists('ExtensionSmartSeoSchema')) {
                throw new Exception('ExtensionSmartSeoSchema class not found. Please check if core extension file exists.');
            }
            
            $extension = new ExtensionSmartSeoSchema();
            $schema = $extension->generateCompleteSchemaForProduct($product_info);
            
            $json = array(
                'error' => false,
                'schema' => $schema
            );
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => 'Schema generation failed: ' . $e->getMessage(),
                'debug' => array(
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                )
            );
            $this->logDebug("Error generando schema: " . $e->getMessage());
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public function generateOthersContent()
    {
        if (ob_get_level()) {
            ob_clean();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $product_id = $this->request->get['product_id'];
            
            if (!$product_id) {
                throw new Exception('Missing product_id parameter');
            }
            
            $this->loadModel('catalog/product');
            $product_info = $this->model_catalog_product->getProduct($product_id);
            
            if (!$product_info) {
                throw new Exception('Product not found: ' . $product_id);
            }
            
            $others_content = $this->generateOthersContentData($product_info);
            
            $this->updateOthersContent($product_id, $others_content);
            
            $json = array(
                'error' => false,
                'message' => 'Others content generated and saved successfully',
                'others_content' => $others_content,
                'timestamp' => date('Y-m-d H:i:s')
            );
            
            $this->logDebug("Others content generado exitosamente para producto: " . $product_id);
            
        } catch (Exception $e) {
            $json = array(
                'error' => true,
                'message' => 'Others content generation failed: ' . $e->getMessage(),
                'debug' => array(
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                )
            );
            $this->logDebug("Error generando others content: " . $e->getMessage());
        }

        echo json_encode($json, JSON_UNESCAPED_UNICODE);
        exit();
    }

    private function setupForm($product_id)
    {
        $form = new AForm('HT');
        $form->setForm(array(
            'form_name' => 'smart_seo_schema_form',
            'update' => ''
        ));

        $this->data['action'] = $this->html->getSecureURL('catalog/smart_seo_schema', '&product_id=' . $product_id);
        $this->data['cancel'] = $this->html->getSecureURL('catalog/product/update', '&product_id=' . $product_id);
        $this->data['form_title'] = $this->language->get('smart_seo_schema_name');
        $this->data['product_id'] = $product_id;

        $this->data['smart_seo_schema_groq_api_key'] = $this->config->get('smart_seo_schema_groq_api_key') ?: '';

        $this->data['form']['id'] = 'smart_seo_schema_form';
        $this->data['form']['form_open'] = $form->getFieldHtml(array(
            'type' => 'form',
            'name' => 'smart_seo_schema_form',
            'action' => $this->data['action'],
            'attr' => 'data-confirm-exit="true" class="aform form-horizontal"'
        ));

        $this->data['form']['submit'] = $form->getFieldHtml(array(
            'type' => 'button',
            'name' => 'submit',
            'text' => $this->language->get('button_save'),
            'style' => 'button1'
        ));

        $this->data['form']['cancel'] = $form->getFieldHtml(array(
            'type' => 'button',
            'name' => 'cancel',
            'text' => $this->language->get('button_cancel'),
            'style' => 'button2'
        ));

        $this->data['test_ai_button'] = $form->getFieldHtml(array(
            'type' => 'button',
            'name' => 'test_ai',
            'text' => $this->language->get('button_test_ai_connection'),
            'style' => 'btn btn-info',
            'attr' => 'type="button" onclick="testAIConnection()"'
        ));

        $this->data['preview_schema_button'] = $form->getFieldHtml(array(
            'type' => 'button',
            'name' => 'preview_schema',
            'text' => $this->language->get('button_preview_schema'),
            'style' => 'btn btn-success',
            'attr' => 'type="button" onclick="previewSchema()"'
        ));

        $this->setupSchemaFields($form);
    }

    private function setupSchemaFields($form)
    {
        $this->data['entry_custom_description'] = $this->language->get('entry_custom_description') ?: 'Custom Description:';
        $this->data['entry_enable_variants'] = $this->language->get('entry_enable_variants') ?: 'Enable Product Variants:';
        $this->data['entry_faq_content'] = $this->language->get('entry_faq_content') ?: 'FAQ Content:';
        $this->data['entry_howto_content'] = $this->language->get('entry_howto_content') ?: 'HowTo Content:';
        $this->data['entry_review_content'] = $this->language->get('entry_review_content') ?: 'Review Content:';
        
        $this->data['text_section_basic'] = $this->language->get('text_section_basic') ?: 'Basic Settings';
        $this->data['text_section_ai'] = $this->language->get('text_section_ai') ?: 'AI Content Generation';
        
        $this->data['button_test_ai_connection'] = $this->language->get('button_test_ai_connection') ?: 'Test AI Connection';
        $this->data['button_preview_schema'] = $this->language->get('button_preview_schema') ?: 'Preview Schema';

        $this->data['form']['fields']['custom_description'] = $form->getFieldHtml(array(
            'type' => 'textarea',
            'name' => 'custom_description',
            'value' => $this->data['schema_settings']['custom_description'] ?? '',
            'style' => 'large-field'
        ));

        $this->data['form']['fields']['faq_content'] = $form->getFieldHtml(array(
            'type' => 'textarea',
            'name' => 'faq_content',
            'value' => $this->data['schema_settings']['faq_content'] ?? '',
            'style' => 'large-field'
        ));

        $this->data['form']['fields']['howto_content'] = $form->getFieldHtml(array(
            'type' => 'textarea',
            'name' => 'howto_content',
            'value' => $this->data['schema_settings']['howto_content'] ?? '',
            'style' => 'large-field'
        ));

        $this->data['form']['fields']['review_content'] = $form->getFieldHtml(array(
            'type' => 'textarea',
            'name' => 'review_content',
            'value' => $this->data['schema_settings']['review_content'] ?? '',
            'style' => 'large-field'
        ));

        $this->data['form']['fields']['enable_variants'] = $form->getFieldHtml(array(
            'type' => 'checkbox',
            'name' => 'enable_variants',
            'value' => $this->data['schema_settings']['enable_variants'] ?? 1
        ));
    }

    private function setupBreadcrumb($product_id)
    {
        $this->document->initBreadcrumb(array(
            'href' => $this->html->getSecureURL('index/home'),
            'text' => $this->language->get('text_home'),
            'separator' => false
        ));

        $this->document->addBreadcrumb(array(
            'href' => $this->html->getSecureURL('catalog/product'),
            'text' => $this->language->get('heading_title'),
            'separator' => ' :: '
        ));

        $this->document->addBreadcrumb(array(
            'href' => $this->html->getSecureURL('catalog/product/update', '&product_id=' . $product_id),
            'text' => $this->language->get('text_edit') . '&nbsp;' . $this->language->get('text_product'),
            'separator' => ' :: '
        ));

        $this->document->addBreadcrumb(array(
            'href' => $this->html->getSecureURL('catalog/smart_seo_schema', '&product_id=' . $product_id),
            'text' => $this->language->get('smart_seo_schema_name'),
            'separator' => ' :: ',
            'current' => true
        ));
    }

    private function getSchemaSettings($product_id)
    {
        $this->logDebug("Cargando configuración schema para producto: " . $product_id);
        
        try {
            $query = $this->db->query("
                SELECT 
                    custom_description,
                    faq_content,
                    howto_content,
                    review_content,
                    others_content,
                    enable_variants,
                    enable_faq,
                    enable_howto,
                    enable_review,
                    created_date,
                    updated_date
                FROM " . DB_PREFIX . "seo_schema_content 
                WHERE product_id = " . (int)$product_id . "
                LIMIT 1
            ");

            if ($query->num_rows) {
                $settings = $query->row;
                
                $settings['enable_variants'] = (bool)$settings['enable_variants'];
                $settings['enable_faq'] = (bool)$settings['enable_faq'];
                $settings['enable_howto'] = (bool)$settings['enable_howto'];
                $settings['enable_review'] = (bool)$settings['enable_review'];
                
                $this->logDebug("Configuración cargada exitosamente. Campos con contenido: " . 
                    implode(', ', array_filter([
                        $settings['custom_description'] ? 'description' : null,
                        $settings['faq_content'] ? 'faq' : null,
                        $settings['howto_content'] ? 'howto' : null,
                        $settings['review_content'] ? 'review' : null,
                        $settings['others_content'] ? 'others' : null
                    ]))
                );
                
                return $settings;
            } else {
                $this->logDebug("No se encontró configuración para el producto. Retornando valores por defecto.");
                
                return array(
                    'custom_description' => '',
                    'faq_content' => '',
                    'howto_content' => '',
                    'review_content' => '',
                    'others_content' => '',
                    'enable_variants' => true,
                    'enable_faq' => false,
                    'enable_howto' => false,
                    'enable_review' => false
                );
            }
        } catch (Exception $e) {
            $this->logDebug("Error cargando configuración: " . $e->getMessage());
            
            return array(
                'custom_description' => '',
                'faq_content' => '',
                'howto_content' => '',
                'review_content' => '',
                'others_content' => '',
                'enable_variants' => true,
                'enable_faq' => false,
                'enable_howto' => false,
                'enable_review' => false
            );
        }
    }

    private function saveSchemaSettings($product_id)
    {
        $this->logDebug("=== GUARDANDO CONFIGURACIÓN SCHEMA CON OTHERS_CONTENT ===");
        $this->logDebug("Producto ID: " . $product_id);
        $this->logDebug("POST data: " . print_r($this->request->post, true));
        
        try {
            $query = $this->db->query("
                SELECT id 
                FROM " . DB_PREFIX . "seo_schema_content 
                WHERE product_id = " . (int)$product_id . "
                LIMIT 1
            ");

            $data = array(
                'custom_description' => trim($this->request->post['custom_description'] ?? ''),
                'faq_content' => trim($this->request->post['faq_content'] ?? ''),
                'howto_content' => trim($this->request->post['howto_content'] ?? ''),
                'review_content' => trim($this->request->post['review_content'] ?? ''),
                'others_content' => trim($this->request->post['others_content'] ?? ''),
                'enable_variants' => isset($this->request->post['enable_variants']) ? 1 : 0,
                'enable_faq' => !empty($this->request->post['faq_content']) ? 1 : 0,
                'enable_howto' => !empty($this->request->post['howto_content']) ? 1 : 0,
                'enable_review' => !empty($this->request->post['review_content']) ? 1 : 0
            );

            $this->logDebug("Datos procesados: " . print_r($data, true));

            if ($query->num_rows) {
                $this->logDebug("Actualizando registro existente...");
                
                $update_sql = "
                    UPDATE " . DB_PREFIX . "seo_schema_content 
                    SET 
                        custom_description = '" . $this->db->escape($data['custom_description']) . "',
                        faq_content = '" . $this->db->escape($data['faq_content']) . "',
                        howto_content = '" . $this->db->escape($data['howto_content']) . "',
                        review_content = '" . $this->db->escape($data['review_content']) . "',
                        others_content = '" . $this->db->escape($data['others_content']) . "',
                        enable_variants = " . (int)$data['enable_variants'] . ",
                        enable_faq = " . (int)$data['enable_faq'] . ",
                        enable_howto = " . (int)$data['enable_howto'] . ",
                        enable_review = " . (int)$data['enable_review'] . ",
                        updated_date = NOW()
                    WHERE product_id = " . (int)$product_id
                ;
                
                $this->db->query($update_sql);
                $this->logDebug("Registro actualizado exitosamente.");
                
            } else {
                $this->logDebug("Creando nuevo registro...");
                
                $insert_sql = "
                    INSERT INTO " . DB_PREFIX . "seo_schema_content 
                    (
                        product_id, 
                        custom_description, 
                        faq_content, 
                        howto_content, 
                        review_content,
                        others_content,
                        enable_variants,
                        enable_faq,
                        enable_howto,
                        enable_review,
                        created_date,
                        updated_date
                    ) VALUES (
                        " . (int)$product_id . ",
                        '" . $this->db->escape($data['custom_description']) . "',
                        '" . $this->db->escape($data['faq_content']) . "',
                        '" . $this->db->escape($data['howto_content']) . "',
                        '" . $this->db->escape($data['review_content']) . "',
                        '" . $this->db->escape($data['others_content']) . "',
                        " . (int)$data['enable_variants'] . ",
                        " . (int)$data['enable_faq'] . ",
                        " . (int)$data['enable_howto'] . ",
                        " . (int)$data['enable_review'] . ",
                        NOW(),
                        NOW()
                    )
                ";
                
                $this->db->query($insert_sql);
                $this->logDebug("Nuevo registro creado exitosamente.");
            }

            $verify_query = $this->db->query("
                SELECT 
                    LENGTH(custom_description) as desc_len,
                    LENGTH(faq_content) as faq_len,
                    LENGTH(howto_content) as howto_len,
                    LENGTH(review_content) as review_len,
                    LENGTH(others_content) as others_len,
                    updated_date
                FROM " . DB_PREFIX . "seo_schema_content 
                WHERE product_id = " . (int)$product_id
            );
            
            if ($verify_query->num_rows) {
                $verification = $verify_query->row;
                $this->logDebug("Verificación exitosa - Longitudes: desc={$verification['desc_len']}, faq={$verification['faq_len']}, howto={$verification['howto_len']}, review={$verification['review_len']}, others={$verification['others_len']}, updated={$verification['updated_date']}");
            }

        } catch (Exception $e) {
            $this->logDebug("ERROR guardando configuración: " . $e->getMessage());
            $this->logDebug("SQL Error Info: " . $this->db->error);
            
            throw new Exception("Error saving schema settings: " . $e->getMessage());
        }
    }

    private function getProductReviews($product_id)
    {
        $query = $this->db->query("
            SELECT 
                review_id,
                product_id,
                customer_id,
                author,
                text,
                rating,
                verified_purchase,
                status,
                date_added,
                date_modified
            FROM " . DB_PREFIX . "reviews 
            WHERE product_id = " . (int)$product_id . "
            ORDER BY date_added DESC
        ");

        return $query->rows;
    }

    private function optimizeReviewWithAI($review_text, $product_info)
    {
        $api_key = $this->config->get('smart_seo_schema_groq_api_key');
        
        if (!$api_key) {
            throw new Exception('No API key configured');
        }
        
        $prompt = "Optimize this product review to be more helpful and detailed while maintaining authenticity and the original rating sentiment:\n\n";
        $prompt .= "Product: " . $product_info['name'] . "\n";
        $prompt .= "Original review: " . $review_text . "\n\n";
        $prompt .= "Please improve the review by:\n";
        $prompt .= "- Adding more specific details about the product\n";
        $prompt .= "- Enhancing readability and structure\n";
        $prompt .= "- Maintaining the original tone and rating sentiment\n";
        $prompt .= "- Making it more helpful for other customers\n\n";
        $prompt .= "Return ONLY the improved review text, no additional formatting or explanations:";
        
        return $this->callGroqAPI(
            $api_key,
            $this->config->get('smart_seo_schema_groq_model') ?: 'llama-3.1-8b-instant',
            $prompt,
            300
        );
    }

    private function generateExampleReviewWithAI($product_info)
    {
        $api_key = $this->config->get('smart_seo_schema_groq_api_key');
        
        if (!$api_key) {
            throw new Exception('No API key configured');
        }
        
        $rating = rand(3, 5);
        
        $prompt = "Generate a realistic product review for this product. Return ONLY valid JSON with no additional text or formatting.\n\n";
        $prompt .= "Product: " . $product_info['name'] . "\n";
        $prompt .= "Model: " . $product_info['model'] . "\n";
        
        if (!empty($product_info['description'])) {
            $description = strip_tags($product_info['description']);
            $prompt .= "Description: " . substr($description, 0, 300) . "\n";
        }
        
        $prompt .= "\nGenerate a " . $rating . "-star review with these exact JSON fields:\n";
        $prompt .= '{"author": "realistic_name", "text": "detailed_review_100_to_200_words", "rating": ' . $rating . ', "verified_purchase": 1, "status": 1}' . "\n\n";
        $prompt .= "Make the review sound authentic and helpful for potential buyers. Return ONLY the JSON object:";
        
        $response = $this->callGroqAPI(
            $api_key,
            $this->config->get('smart_seo_schema_groq_model') ?: 'llama-3.1-8b-instant',
            $prompt,
            400
        );
        
        $clean_response = trim($response);
        $clean_response = preg_replace('/^[^{]*/', '', $clean_response);
        $clean_response = preg_replace('/[^}]*$/', '', $clean_response);
        
        $review_data = json_decode($clean_response, true);
        if (!$review_data || !isset($review_data['author']) || !isset($review_data['text']) || !isset($review_data['rating'])) {
            $this->logDebug("Failed to parse JSON response: " . $clean_response);
            
            $fallback_data = array(
                'author' => 'Customer Review',
                'text' => $this->extractTextFromResponse($response, $product_info['name']),
                'rating' => $rating,
                'verified_purchase' => 1,
                'status' => 1
            );
            return $fallback_data;
        }
        
        $review_data['rating'] = (int)$review_data['rating'];
        $review_data['verified_purchase'] = isset($review_data['verified_purchase']) ? (int)$review_data['verified_purchase'] : 1;
        $review_data['status'] = isset($review_data['status']) ? (int)$review_data['status'] : 1;
        
        return $review_data;
    }

    private function extractTextFromResponse($response, $product_name)
    {
        $lines = explode("\n", $response);
        $text_lines = array();
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (!empty($line) && 
                !preg_match('/^[\{\}\[\]"]/', $line) && 
                !preg_match('/(author|rating|verified|status)/', $line) &&
                strlen($line) > 20) {
                $text_lines[] = $line;
            }
        }
        
        if (!empty($text_lines)) {
            return implode(' ', array_slice($text_lines, 0, 3));
        }
        
        return "Great product! The " . $product_name . " works exactly as described and meets all my expectations. Would definitely recommend to others.";
    }

    private function createReview($product_id, $author, $text, $rating, $verified_purchase, $status)
    {
        $this->db->query("
            INSERT INTO " . DB_PREFIX . "reviews 
            (product_id, customer_id, author, text, rating, verified_purchase, status, date_added, date_modified) 
            VALUES (
                " . (int)$product_id . ",
                0,
                '" . $this->db->escape($author) . "',
                '" . $this->db->escape($text) . "',
                " . (int)$rating . ",
                " . (int)$verified_purchase . ",
                " . (int)$status . ",
                NOW(),
                NOW()
            )
        ");
    }

    private function updateReview($review_id, $author, $text, $rating, $verified_purchase, $status)
    {
        $this->db->query("
            UPDATE " . DB_PREFIX . "reviews 
            SET 
                author = '" . $this->db->escape($author) . "',
                text = '" . $this->db->escape($text) . "',
                rating = " . (int)$rating . ",
                verified_purchase = " . (int)$verified_purchase . ",
                status = " . (int)$status . ",
                date_modified = NOW()
            WHERE review_id = " . (int)$review_id
        );
    }

    private function generateOthersContentData($product_info)
    {
        $others_data = array();
        
        $others_data['shippingDetails'] = array(
            "@type" => "OfferShippingDetails",
            "shippingRate" => array(
                "@type" => "MonetaryAmount",
                "value" => "5.99",
                "currency" => "USD"
            ),
            "shippingDestination" => array(
                "@type" => "DefinedRegion",
                "addressCountry" => "US"
            ),
            "deliveryTime" => array(
                "@type" => "ShippingDeliveryTime",
                "handlingTime" => array(
                    "@type" => "QuantitativeValue",
                    "minValue" => 1,
                    "maxValue" => 2,
                    "unitCode" => "d"
                ),
                "transitTime" => array(
                    "@type" => "QuantitativeValue",
                    "minValue" => 3,
                    "maxValue" => 5,
                    "unitCode" => "d"
                )
            )
        );
        
        $others_data['hasMerchantReturnPolicy'] = array(
            "@type" => "MerchantReturnPolicy",
            "applicableCountry" => "US",
            "returnPolicyCategory" => "https://schema.org/MerchantReturnFiniteReturnWindow",
            "merchantReturnDays" => 30,
            "returnMethod" => "https://schema.org/ReturnByMail",
            "returnFees" => "https://schema.org/FreeReturn"
        );
        
        if (!empty($product_info['model'])) {
            $others_data['productGroupID'] = $product_info['model'];
        } elseif (!empty($product_info['sku'])) {
            $others_data['productGroupID'] = $product_info['sku'];
        }
        
        $additionalProperties = array();
        
        if (!empty($product_info['weight'])) {
            $additionalProperties[] = array(
                '@type' => 'PropertyValue',
                'name' => 'Weight',
                'value' => $product_info['weight'] . ' ' . ($product_info['weight_class'] ?? 'kg')
            );
        }
        
        if (!empty($product_info['length']) || !empty($product_info['width']) || !empty($product_info['height'])) {
            $dimensions = trim(
                ($product_info['length'] ?? '0') . ' x ' . 
                ($product_info['width'] ?? '0') . ' x ' . 
                ($product_info['height'] ?? '0')
            );
            if ($dimensions !== '0 x 0 x 0') {
                $additionalProperties[] = array(
                    '@type' => 'PropertyValue',
                    'name' => 'Dimensions',
                    'value' => $dimensions . ' ' . ($product_info['length_class'] ?? 'cm')
                );
            }
        }
        
        if (!empty($additionalProperties)) {
            $others_data['additionalProperty'] = $additionalProperties;
        }
        
        return $others_data;
    }

    private function updateOthersContent($product_id, $others_content)
    {
        $json_content = json_encode($others_content, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        $query = $this->db->query("
            SELECT id 
            FROM " . DB_PREFIX . "seo_schema_content 
            WHERE product_id = " . (int)$product_id . "
            LIMIT 1
        ");
        
        if ($query->num_rows) {
            $this->db->query("
                UPDATE " . DB_PREFIX . "seo_schema_content 
                SET 
                    others_content = '" . $this->db->escape($json_content) . "',
                    updated_date = NOW()
                WHERE product_id = " . (int)$product_id
            );
        } else {
            $this->db->query("
                INSERT INTO " . DB_PREFIX . "seo_schema_content 
                (product_id, others_content, created_date, updated_date) 
                VALUES (
                    " . (int)$product_id . ",
                    '" . $this->db->escape($json_content) . "',
                    NOW(),
                    NOW()
                )
            ");
        }
    }

    private function getProductVariants($product_id)
    {
        $db = $this->db;
        $language_id = $this->getAdminDefaultLanguageId();

        $sql = "
            SELECT 
                pov.product_option_value_id,
                pov.sku,
                pov.price,
                pov.prefix,
                COALESCE(povd.name, CONCAT('Variant ', pov.product_option_value_id)) as variant_name
            FROM " . DB_PREFIX . "product_option_values pov
            LEFT JOIN " . DB_PREFIX . "product_option_value_descriptions povd 
                ON pov.product_option_value_id = povd.product_option_value_id 
                AND povd.language_id = " . (int)$language_id . "
            WHERE pov.product_id = " . (int)$product_id . "
            ORDER BY pov.product_option_value_id
            LIMIT 10
        ";

        $query = $db->query($sql);
        return $query->rows;
    }

    private function checkAIConnection()
    {
        $api_key = $this->config->get('smart_seo_schema_groq_api_key');
        return !empty($api_key);
    }

    private function getAdminDefaultLanguageId()
    {
        $query = $this->db->query("
            SELECT l.language_id 
            FROM " . DB_PREFIX . "settings s
            INNER JOIN " . DB_PREFIX . "languages l ON s.value = l.code
            WHERE s.key = 'admin_language'
            LIMIT 1
        ");
        
        if ($query->num_rows) {
            return (int)$query->row['language_id'];
        }
        
        return (int)$this->config->get('config_language_id');
    }

    protected function validateForm()
    {
        if (!$this->user->hasPermission('modify', 'catalog/smart_seo_schema')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    private function generateMultipleAIContentWithTokenDivision($product_info, $content_types)
    {
        $this->logDebug("=== INICIO DIVISIÓN INTELIGENTE DE TOKENS ===");
        $this->logDebug("Producto: " . $product_info['name']);
        $this->logDebug("Tipos de contenido solicitados: " . implode(', ', $content_types));
        
        $base_max_tokens = (int)$this->config->get('smart_seo_schema_ai_max_tokens') ?: 800;
        $content_count = count($content_types);
        
        $this->logDebug("Tokens base configurados: " . $base_max_tokens);
        $this->logDebug("Cantidad de tipos de contenido: " . $content_count);
        
        $min_tokens_per_content = 100;
        $tokens_per_content = intval($base_max_tokens / $content_count);
        
        if ($tokens_per_content < $min_tokens_per_content) {
            $tokens_per_content = $min_tokens_per_content;
            $actual_total_tokens = $tokens_per_content * $content_count;
            $this->logDebug("AJUSTE: Tokens insuficientes. Subiendo a mínimo de {$min_tokens_per_content} por tipo");
            $this->logDebug("Total real de tokens que se usarán: " . $actual_total_tokens);
        } else {
            $actual_total_tokens = $base_max_tokens;
            $this->logDebug("División estándar: {$tokens_per_content} tokens por tipo");
        }
        
        $existing_description = '';
        if (!empty($product_info['description'])) {
            $existing_description = strip_tags($product_info['description']);
            $existing_description = substr($existing_description, 0, 600);
        }
        
        $prompt = "You are a professional content writer. Create high-quality content for this product:\n\n";
        $prompt .= "Product: " . $product_info['name'] . "\n";
        $prompt .= "Model: " . $product_info['model'] . "\n";
        
        if ($existing_description) {
            $prompt .= "Current description: " . $existing_description . "\n\n";
        }
        
        $prompt .= "Generate the following content sections with clear headers:\n\n";
        
        foreach ($content_types as $type) {
            $prompt .= $this->buildCleanPromptSection($type, $tokens_per_content);
        }
        
        $prompt .= "\nIMPORTANT GUIDELINES:\n";
        $prompt .= "- Write professionally and concisely\n";
        $prompt .= "- Use clear section headers with === markers\n";
        $prompt .= "- Focus on key information and benefits\n";
        $prompt .= "- Keep each section appropriately sized for its purpose\n";
        
        $this->logDebug("Prompt final creado - Longitud: " . strlen($prompt));
        $this->logDebug("Tokens por sección: " . $tokens_per_content);
        $this->logDebug("Total máximo permitido: " . $actual_total_tokens);
        
        $response = $this->callGroqAPI(
            $this->config->get('smart_seo_schema_groq_api_key'),
            $this->config->get('smart_seo_schema_groq_model') ?: 'llama-3.1-8b-instant',
            $prompt,
            $actual_total_tokens
        );
        
        if (!$response) {
            throw new Exception('No response from AI API with token division');
        }
        
        $this->logDebug("Respuesta recibida con división de tokens - Longitud: " . strlen($response));
        
        $parsed_content = $this->parseMultipleAIResponse($response, $content_types);
        
        $this->logDebug("=== RESULTADO DIVISIÓN DE TOKENS ===");
        foreach ($parsed_content as $type => $content) {
            $word_count = str_word_count($content);
            $char_count = strlen($content);
            $this->logDebug("Tipo: {$type} | Palabras: {$word_count} | Caracteres: {$char_count}");
        }
        
        return $parsed_content;
    }

    private function buildCleanPromptSection($content_type, $tokens_per_content)
    {
        $section = "";
        
        switch ($content_type) {
            case 'description':
                $section .= "===DESCRIPTION===\n";
                $section .= "Create a concise, SEO-optimized product description. Focus on:\n";
                $section .= "- Key features and benefits\n";
                $section .= "- Technical specifications\n";
                $section .= "- Use cases and target audience\n";
                $section .= "Write professionally and keep it appropriately detailed.\n\n";
                break;
                
            case 'faq':
                $faq_count = $this->config->get('smart_seo_schema_faq_count') ?: 3;
                $section .= "===FAQ===\n";
                $section .= "Create {$faq_count} useful Q&A pairs in this format:\n";
                $section .= "Q: [question]\n";
                $section .= "A: [answer]\n";
                $section .= "Cover specifications, compatibility, and common usage questions.\n\n";
                break;
                
            case 'howto':
                $steps_count = $this->config->get('smart_seo_schema_howto_steps_count') ?: 5;
                $section .= "===HOWTO===\n";
                $section .= "Create {$steps_count} clear steps for installation, setup, or usage:\n";
                $section .= "Step 1: [instruction]\n";
                $section .= "Step 2: [instruction]\n";
                $section .= "Focus on practical, actionable guidance.\n\n";
                break;
                
            case 'review':
                $section .= "===REVIEW===\n";
                $section .= "Write a professional product review including:\n";
                $section .= "- Main advantages and benefits\n";
                $section .= "- Performance highlights\n";
                $section .= "- Overall recommendation\n";
                $section .= "Keep it balanced and informative.\n\n";
                break;
        }
        
        return $section;
    }

    private function parseMultipleAIResponse($response, $content_types)
    {
        $this->logDebug("=== PARSEANDO RESPUESTA CON DIVISIÓN DE TOKENS ===");
        
        $parsed_content = array();
        
        $sections = array(
            'description' => '===DESCRIPTION===',
            'faq' => '===FAQ===',
            'howto' => '===HOWTO===',
            'review' => '===REVIEW==='
        );
        
        foreach ($content_types as $type) {
            if (!isset($sections[$type])) {
                $this->logDebug("Tipo no reconocido: " . $type);
                continue;
            }
            
            $marker = $sections[$type];
            $start_pos = strpos($response, $marker);
            
            if ($start_pos !== false) {
                $start_pos += strlen($marker);
                
                $end_pos = strlen($response);
                foreach ($sections as $other_marker) {
                    if ($other_marker === $marker) continue;
                    $next_pos = strpos($response, $other_marker, $start_pos);
                    if ($next_pos !== false && $next_pos < $end_pos) {
                        $end_pos = $next_pos;
                    }
                }
                
                $content = substr($response, $start_pos, $end_pos - $start_pos);
                $content = trim($content);
                
                $content = preg_replace('/\b(?:EXACTLY|exactly)\s+\d+\s+tokens?\s+(?:MAX|max)\b/i', '', $content);
                $content = preg_replace('/\(\s*EXACTLY\s+\d+\s+tokens?\s+MAX\s*\)/i', '', $content);
                $content = preg_replace('/\b\d+\s+tokens?\s+(?:each|MAX|max)\b/i', '', $content);
                
                $content = preg_replace('/^[\r\n]+/', '', $content);
                $content = preg_replace('/[\r\n]+$/', '', $content);
                $content = trim($content);
                
                if (!empty($content)) {
                    $parsed_content[$type] = $content;
                    $this->logDebug("Extraído {$type}: " . strlen($content) . " caracteres, " . str_word_count($content) . " palabras");
                } else {
                    $this->logDebug("Contenido vacío para: " . $type);
                }
            } else {
                $this->logDebug("Marcador no encontrado para: " . $type);
            }
        }
        
        if (empty($parsed_content) && !empty($content_types)) {
            $this->logDebug("FALLBACK: Sin marcadores encontrados, intentando división por líneas");
            
            $first_type = $content_types[0];
            $lines = explode("\n", trim($response));
            $clean_lines = array_filter($lines, function($line) {
                return !empty(trim($line));
            });
            
            if (!empty($clean_lines)) {
                $fallback_content = implode("\n", array_slice($clean_lines, 0, 10));
                $fallback_content = preg_replace('/\b(?:EXACTLY|exactly)\s+\d+\s+tokens?\s+(?:MAX|max)\b/i', '', $fallback_content);
                $fallback_content = preg_replace('/\(\s*EXACTLY\s+\d+\s+tokens?\s+MAX\s*\)/i', '', $fallback_content);
                $fallback_content = trim($fallback_content);
                
                $parsed_content[$first_type] = $fallback_content;
                $this->logDebug("Fallback aplicado para {$first_type}: " . strlen($fallback_content) . " caracteres");
            }
        }
        
        $this->logDebug("Parsing completado - Tipos extraídos: " . implode(', ', array_keys($parsed_content)));
        
        return $parsed_content;
    }

    private function callGroqAPI($api_key, $model, $prompt, $max_tokens = null)
    {
        $url = 'https://api.groq.com/openai/v1/chat/completions';
        
        if (!function_exists('curl_init')) {
            throw new Exception('cURL extension is not available on this server');
        }
        
        $tokens_to_use = $max_tokens ?: (int)$this->config->get('smart_seo_schema_ai_max_tokens') ?: 800;
        
        $data = [
            'model' => $model,
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $tokens_to_use,
            'temperature' => (float)$this->config->get('smart_seo_schema_ai_temperature') ?: 0.7
        ];

        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $api_key,
            'User-Agent: AbanteCart-SmartSEOSchema/2.0'
        ];

        $this->logDebug("=== LLAMADA API CON CONTROL DE TOKENS ===");
        $this->logDebug("URL: " . $url);
        $this->logDebug("Modelo: " . $model);
        $this->logDebug("Max tokens (específicos): " . $tokens_to_use);
        $this->logDebug("Temperature: " . $data['temperature']);
        $this->logDebug("Prompt length: " . strlen($prompt) . " caracteres");

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, (int)$this->config->get('smart_seo_schema_ai_timeout') ?: 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        $curl_info = curl_getinfo($ch);
        curl_close($ch);

        $this->logDebug("=== RESPUESTA API ===");
        $this->logDebug("HTTP Code: " . $http_code);
        $this->logDebug("Response length: " . strlen($response) . " caracteres");
        $this->logDebug("cURL Error: " . ($curl_error ?: 'None'));
        $this->logDebug("Total time: " . $curl_info['total_time'] . "s");
        $this->logDebug("Connect time: " . $curl_info['connect_time'] . "s");

        if ($curl_error) {
            throw new Exception("cURL Error: " . $curl_error);
        }

        if ($response === false) {
            throw new Exception("cURL failed to get response");
        }

        if ($response) {
            $this->logDebug("Raw response preview: " . substr($response, 0, 300) . "...");
        }

        if ($http_code == 200 && $response) {
            $decoded = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("JSON decode error: " . json_last_error_msg() . ". Response: " . substr($response, 0, 200));
            }
            
            if (isset($decoded['choices'][0]['message']['content'])) {
                $content = $decoded['choices'][0]['message']['content'];
                $this->logDebug("Contenido extraído exitosamente: " . strlen($content) . " caracteres");
                
                if (isset($decoded['usage'])) {
                    $usage = $decoded['usage'];
                    $this->logDebug("Tokens utilizados: prompt=" . ($usage['prompt_tokens'] ?? 'N/A') . 
                                  ", completion=" . ($usage['completion_tokens'] ?? 'N/A') . 
                                  ", total=" . ($usage['total_tokens'] ?? 'N/A'));
                }
                
                return $content;
            } else {
                $this->logDebug("Estructura de respuesta inesperada: " . print_r($decoded, true));
                throw new Exception("Unexpected response structure from API. Missing choices[0].message.content");
            }
        }

        $error_details = null;
        if ($response) {
            $error_details = json_decode($response, true);
        }

        switch ($http_code) {
            case 400:
                $error_msg = "Bad Request. Model '{$model}' may not exist or request is malformed.";
                if ($error_details && isset($error_details['error']['message'])) {
                    $error_msg .= " API Error: " . $error_details['error']['message'];
                }
                $error_msg .= " Check available models at https://console.groq.com/docs/models";
                throw new Exception($error_msg);
                
            case 401:
                $error_msg = "Unauthorized. Invalid API key.";
                if ($error_details && isset($error_details['error']['message'])) {
                    $error_msg .= " API Error: " . $error_details['error']['message'];
                }
                throw new Exception($error_msg);
                
            case 429:
                $error_msg = "Rate limit exceeded. Please try again later.";
                if ($error_details && isset($error_details['error']['message'])) {
                    $error_msg .= " API Error: " . $error_details['error']['message'];
                }
                throw new Exception($error_msg);
                
            case 422:
                $error_msg = "Unprocessable Entity. Model '{$model}' may not be available.";
                if ($error_details && isset($error_details['error']['message'])) {
                    $error_msg .= " API Error: " . $error_details['error']['message'];
                }
                $error_msg .= " Check https://console.groq.com/docs/models";
                throw new Exception($error_msg);
                
            case 0:
                throw new Exception("Network error: Could not connect to Groq API. Check internet connection and firewall.");
                
            default:
                $error_msg = "API call failed with HTTP code: " . $http_code;
                if ($error_details && isset($error_details['error']['message'])) {
                    $error_msg .= " - " . $error_details['error']['message'];
                } elseif ($response) {
                    $error_msg .= " - Response: " . substr($response, 0, 200);
                }
                throw new Exception($error_msg);
        }
    }

    private function logDebug($message)
    {
        try {
            $log_file = DIR_LOGS . 'smart_seo_schema_debug.log';
            $timestamp = date('Y-m-d H:i:s');
            $log_entry = "[{$timestamp}] {$message}" . PHP_EOL;
            
            $log_dir = dirname($log_file);
            if (!is_dir($log_dir)) {
                mkdir($log_dir, 0755, true);
            }
            
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        } catch (Exception $e) {
            try {
                if ($this->config && $this->config->get('smart_seo_schema_debug_mode')) {
                    $warning = new AWarning('Smart SEO Schema Debug: ' . $message);
                    $warning->toLog();
                }
            } catch (Exception $e2) {
                error_log("Smart SEO Schema Debug: " . $message);
            }
        }
    }
}