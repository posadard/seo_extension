<?php
if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}
if (!class_exists('ExtensionSmartSeoSchema')) {
    require_once(DIR_EXT . 'smart_seo_schema/core/smart_seo_schema.php');
}
$controllers = [
    'storefront' => [],
    'admin'      => [
        'pages/catalog/smart_seo_schema',
    ],
];
$models = [
    'storefront' => [],
    'admin'      => [],
];
$templates = [
    'storefront' => [
        'pages/product/product.post.tpl',
        'pages/product/faq_tab.tpl',
        'pages/product/howto_tab.tpl',
    ],
    'admin'      => [
        'pages/smart_seo_schema/smart_seo_schema_form.tpl',
        'pages/smart_seo_schema/reviews_section.tpl',
        'pages/smart_seo_schema/tabs.tpl',
    ],
];
$languages = [
    'storefront' => [
        'english/smart_seo_schema/smart_seo_schema',
    ],
    'admin'      => [
        'english/smart_seo_schema/smart_seo_schema',
    ],
];